"use client"
import { useEffect, useRef } from "react"
import { initFastlane } from './init_fastlane'


declare global {
  interface Window {
    paypal?: any
  }
}

type PaypalOrder = any

interface Props {
  total?: number
  onSuccess?: (order: PaypalOrder) => void
  onError?: (err: unknown) => void
  successRedirectUrl?: string
}

export default function PaypalButton({
  total = 49.99,
  onSuccess,
  onError,
  successRedirectUrl = "/success",
}: Props) {
  const containerRef = useRef<HTMLDivElement>(null)
  const buttonsRef = useRef<any>(null)
  const onSuccessRef = useRef(onSuccess)
  const onErrorRef = useRef(onError)

  useEffect(() => { onSuccessRef.current = onSuccess }, [onSuccess])
  useEffect(() => { onErrorRef.current = onError }, [onError])

  useEffect(() => {
    let cancelled = false

    const ensureSdk = async () => {
      if (window.paypal) return
      let script = document.getElementById("paypal-sdk") as HTMLScriptElement | null
      if (!script) {
        script = document.createElement("script")
        script.id = "paypal-sdk"
        // Inclut Fastlane + buttons
        script.src = "https://www.paypal.com/sdk/js?client-id=sb&currency=EUR&components=buttons,fastlane"
        script.src = "https://www.paypal.com/sdk/js?client-id=sb&currency=EUR&components=buttons,fastlane&locale=fr_FR"

        script.async = true
        await new Promise<void>((resolve, reject) => {
          script!.onload = () => {
            console.log("[PayPal SDK] loaded")
            resolve()
          }
          script!.onerror = (ev) => {
            console.error("[PayPal SDK] failed to load", ev)
            reject(new Error("Failed to load PayPal SDK"))
          }
          document.body.appendChild(script!)
        })
      } else {
        await new Promise<void>((resolve) => {
          if (window.paypal) resolve()
          else script!.addEventListener("load", () => resolve(), { once: true })
        })
      }
    }

    const renderButtons = () => {
      if (!window.paypal || !containerRef.current) return

      // Initialiser Fastlane en français
      initFastlane()

      if (buttonsRef.current && typeof buttonsRef.current.close === "function") {
        try { buttonsRef.current.close() } catch {}
        buttonsRef.current = null
      }
      containerRef.current.innerHTML = ""

      buttonsRef.current = window.paypal.Buttons({
        style: {
          layout: "horizontal",
          color: "gold",
          shape: "pill",
          label: "paypal",
          tagline: false,
        },
        createOrder: (_: any, actions: any) => {
          return actions.order.create({
            purchase_units: [
              { amount: { value: total.toFixed(2), currency_code: "EUR" } },
            ],
            application_context: { shipping_preference: "NO_SHIPPING" },
          })
        },
        onApprove: async (_: any, actions: any) => {
          try {
            const order = await actions.order.capture()
            if (typeof onSuccessRef.current === "function") {
              onSuccessRef.current(order)
              return
            }
            const payer = order?.payer ?? {}
            const email = payer?.email_address || ""
            const name = [payer?.name?.given_name, payer?.name?.surname].filter(Boolean).join(" ")
            const params = new URLSearchParams({ total: total.toFixed(2), email, name })
            window.location.href = `${successRedirectUrl}?${params.toString()}`
          } catch (e) {
            if (typeof onErrorRef.current === "function") onErrorRef.current(e)
            else alert("Erreur lors de la capture du paiement.")
          }
        },
        onError: (err: unknown) => {
          if (typeof onErrorRef.current === "function") onErrorRef.current(err)
          else alert("Paiement PayPal impossible pour le moment.")
        },
      })

      try {
        buttonsRef.current.render(containerRef.current)
      } catch (e) {
        console.error("[PayPal] error rendering buttons:", e)
      }
    }

    ensureSdk().then(() => { if (!cancelled) renderButtons() }).catch((e) => {
      if (typeof onErrorRef.current === "function") onErrorRef.current(e)
    })

    return () => {
      cancelled = true
      if (buttonsRef.current && typeof buttonsRef.current.close === "function") {
        try { buttonsRef.current.close() } catch {}
        buttonsRef.current = null
      }
      if (containerRef.current) containerRef.current.innerHTML = ""
    }
  }, [total, successRedirectUrl])

  return (
    <div>
      <div className="card" style={{ padding: 16 }}>
        <div className="row" style={{ justifyContent: "space-between" }}>
          <div>
            <div className="card__meta">Total TTC</div>
            <h3 style={{ margin: 0 }}>{total.toFixed(2)} €</h3>
          </div>
          <span className="badge">Paiement sécurisé</span>
        </div>
        <div ref={containerRef} />
      </div>
      <p className="card__meta center">Tu seras redirigé après confirmation.</p>
    </div>
  )
}
